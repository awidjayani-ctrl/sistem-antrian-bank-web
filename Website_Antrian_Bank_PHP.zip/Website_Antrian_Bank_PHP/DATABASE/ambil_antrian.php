<?php
session_start();
include 'db.php';
if ($_SESSION['role'] != 'nasabah') {
    header("Location: index.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = $_SESSION['username'];
    $layanan = $_POST['layanan'];

    $cek = mysqli_query($conn, "SELECT COUNT(*) AS total FROM antrian");
    $row = mysqli_fetch_assoc($cek);
    $nomor = "A" . str_pad($row['total'] + 1, 3, "0", STR_PAD_LEFT);

    $query = "INSERT INTO antrian (nomor_antrian, nama_nasabah, layanan) VALUES ('$nomor', '$nama', '$layanan')";
    mysqli_query($conn, $query);
    echo "<script>alert('Nomor antrian kamu: $nomor');window.location='dashboard_user.php';</script>";
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Ambil Antrian</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Ambil Antrian Baru</h2>
    <form method="POST">
        <label>Pilih Layanan</label>
        <select name="layanan" required>
            <option value="Customer Service">Customer Service</option>
            <option value="Teller">Teller</option>
            <option value="Kredit">Kredit</option>
        </select>
        <button type="submit">Ambil Antrian</button>
    </form>
</body>
</html>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Daftar Akun - Antrian Bank</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Daftar Akun Baru</h2>
        <form action="proses_register.php" method="POST">
            <label>Username</label>
            <input type="text" name="username" required>

            <label>Nama Lengkap</label>
            <input type="text" name="nama_lengkap" required>

            <label>Password</label>
            <input type="password" name="password" required>

            <button type="submit">Daftar</button>
            <p>Sudah punya akun? <a href="index.php">Login di sini</a></p>
        </form>
    </div>
</body>
</html>
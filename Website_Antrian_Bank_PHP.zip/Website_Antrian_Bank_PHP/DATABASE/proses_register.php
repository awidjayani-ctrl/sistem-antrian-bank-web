<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = md5($_POST['password']);
    $nama_lengkap = $_POST['nama_lengkap'];

    $query = "INSERT INTO users (username, password, nama_lengkap) 
              VALUES ('$username', '$password', '$nama_lengkap')";

    if (mysqli_query($conn, $query)) {
        header("Location: index.php?register=success");
        exit;
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
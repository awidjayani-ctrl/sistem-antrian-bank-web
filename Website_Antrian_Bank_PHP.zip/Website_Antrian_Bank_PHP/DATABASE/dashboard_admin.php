<?php
session_start();
include 'db.php';
if ($_SESSION['role'] != 'admin') {
    header("Location: index.php");
    exit;
}
$antrian = mysqli_query($conn, "SELECT * FROM view_laporan_antrian");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Dashboard Admin</h2>
    <a href="index.php">Logout</a>
    <table>
        <tr>
            <th>No</th>
            <th>Nomor Antrian</th>
            <th>Nama Nasabah</th>
            <th>Layanan</th>
            <th>Loket</th>
            <th>Status</th>
        </tr>
        <?php $no=1; while($row=mysqli_fetch_assoc($antrian)): ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= $row['nomor_antrian'] ?></td>
            <td><?= $row['nama_nasabah'] ?></td>
            <td><?= $row['layanan'] ?></td>
            <td><?= $row['nama_loket'] ?></td>
            <td><?= $row['status'] ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
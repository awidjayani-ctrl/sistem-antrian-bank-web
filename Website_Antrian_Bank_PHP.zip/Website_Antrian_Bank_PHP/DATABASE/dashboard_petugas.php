<?php
session_start();
include 'db.php';
if ($_SESSION['role'] != 'petugas') {
    header("Location: index.php");
    exit;
}

$antrian = mysqli_query($conn, "SELECT * FROM antrian WHERE status='menunggu' ORDER BY waktu_daftar ASC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Petugas</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Dashboard Petugas</h2>
    <a href="index.php">Logout</a>
    <table>
        <tr>
            <th>No Antrian</th>
            <th>Nama Nasabah</th>
            <th>Layanan</th>
            <th>Aksi</th>
        </tr>
        <?php while($row=mysqli_fetch_assoc($antrian)): ?>
        <tr>
            <td><?= $row['nomor_antrian'] ?></td>
            <td><?= $row['nama_nasabah'] ?></td>
            <td><?= $row['layanan'] ?></td>
            <td><a href="proses_panggil.php?id=<?= $row['id_antrian'] ?>">Panggil</a></td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>

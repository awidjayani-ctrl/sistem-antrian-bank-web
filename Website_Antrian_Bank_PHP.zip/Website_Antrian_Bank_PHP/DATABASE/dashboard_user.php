<?php
session_start();
include 'db.php';
if ($_SESSION['role'] != 'nasabah') {
    header("Location: index.php");
    exit;
}
$antrian = mysqli_query($conn, "SELECT * FROM antrian WHERE nama_nasabah='{$_SESSION['username']}' ORDER BY waktu_daftar DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Nasabah</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Selamat datang, <?= $_SESSION['username']; ?></h2>
    <a href="ambil_antrian.php">Ambil Antrian</a> | <a href="index.php">Logout</a>
    <table>
        <tr>
            <th>No Antrian</th>
            <th>Layanan</th>
            <th>Status</th>
            <th>Waktu</th>
        </tr>
        <?php while($row=mysqli_fetch_assoc($antrian)): ?>
        <tr>
            <td><?= $row['nomor_antrian'] ?></td>
            <td><?= $row['layanan'] ?></td>
            <td><?= $row['status'] ?></td>
            <td><?= $row['waktu_daftar'] ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>

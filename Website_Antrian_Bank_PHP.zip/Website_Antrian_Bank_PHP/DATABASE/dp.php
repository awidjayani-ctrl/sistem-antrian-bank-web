<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "db_antrian_bank";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>